select title from (values('ISO IEC 9075 feature compliance test suite')) v(title)
